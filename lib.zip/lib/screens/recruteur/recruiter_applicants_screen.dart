import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../../theme/app_colors.dart';
import '../../services/offers_service.dart';
import '../../l10n/app_localizations.dart';

class RecruiterApplicantsScreen extends StatelessWidget {
  const RecruiterApplicantsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final recruiterId = FirebaseAuth.instance.currentUser?.uid;
    final offersService = OffersService();

    return Scaffold(
      backgroundColor: c.bg,
      appBar: AppBar(
        backgroundColor: c.surface,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new_rounded, color: c.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(AppLocalizations.of(context).allCandidates, style: TextStyle(color: c.textPrimary, fontFamily: 'Inter', fontWeight: FontWeight.w700)),
        centerTitle: true,
      ),
      body: recruiterId == null
          ? Center(child: Text(AppLocalizations.of(context).pleaseSignIn))
          : StreamBuilder<List<Map<String, dynamic>>>(
              stream: offersService.getAllApplicantsForRecruiter(recruiterId),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (snapshot.hasError) {
                  return Center(child: Text('Error: ${snapshot.error}', style: TextStyle(color: c.textMuted)));
                }
                
                final applicants = snapshot.data ?? [];
                if (applicants.isEmpty) {
                  return Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.people_outline_rounded, size: 64, color: c.textMuted),
                        const SizedBox(height: 16),
                        Text(AppLocalizations.of(context).noApplicantsYet, style: TextStyle(color: c.textPrimary, fontSize: 16, fontFamily: 'Inter', fontWeight: FontWeight.w600)),
                        const SizedBox(height: 8),
                        Text(AppLocalizations.of(context).candidatesWillAppear, style: TextStyle(color: c.textMuted, fontSize: 14)),
                      ],
                    ),
                  );
                }

                return ListView.separated(
                  padding: const EdgeInsets.all(24),
                  itemCount: applicants.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 12),
                  itemBuilder: (_, index) {
                    final app = applicants[index];
                    final applicantId = app['applicantId']; // ✅ استخراج معرف الطالب
                    
                    return _ApplicantCard(
                      application: app,
                      onUpdateStatus: (status, message) async {
                        final success = await offersService.updateApplicationStatus(
                          applicationId: app['id'],
                          status: status,
                          message: message,
                        );
                        if (context.mounted && success) {
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                            content: Text(AppLocalizations.of(context).statusUpdated), backgroundColor: AppColors.green,
                          ));
                        }
                      },
                      // ✅ عند النقر على الصورة: اذهب للبروفايل العام للطالب
                      onAvatarTap: applicantId != null ? () {
                        Navigator.pushNamed(context, '/public/profile', arguments: {
                          'userId': applicantId,
                          'role': 'etudiant',
                        });
                      } : null,
                    );
                  },
                );
              },
            ),
    );
  }
}

// ── Applicant Card (مُحدّث مع Avatar قابل للنقر) ──
class _ApplicantCard extends StatefulWidget {
  final Map<String, dynamic> application;
  final Function(String, String?) onUpdateStatus;
  final VoidCallback? onAvatarTap;  // ✅ جديد: استدعاء عند النقر على الصورة

  const _ApplicantCard({
    required this.application, 
    required this.onUpdateStatus,
    this.onAvatarTap,  // ✅ جديد
  });

  @override
  State<_ApplicantCard> createState() => _ApplicantCardState();
}

class _ApplicantCardState extends State<_ApplicantCard> {
  late String _currentStatus;

  @override
  void initState() {
    super.initState();
    _currentStatus = widget.application['status'] ?? 'pending';
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case 'accepted': return AppColors.green;
      case 'rejected': return AppColors.red;
      case 'interview': return AppColors.purple;
      case 'reviewing': return AppColors.primary;
      default: return Colors.grey;
    }
  }

  // ✅ دالة مساعدة: توليد الأحرف الأولى من الاسم (مثل: "Ahmed Hassan" → "AH")
  String _getInitials(String name) {
    if (name.isEmpty) return '?';
    final parts = name.trim().split(' ');
    if (parts.length == 1) return parts[0][0].toUpperCase();
    return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
  }

  @override
  Widget build(BuildContext context) {
    final c = context.colors;
    final app = widget.application;
    final applicantName = app['applicantName'] ?? 'Anonymous';

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: ShapeDecoration(
        color: c.surface,
        shape: RoundedRectangleBorder(side: BorderSide(width: 1.24, color: c.border), borderRadius: BorderRadius.circular(16)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        
        // ✅ الصف الجديد: Avatar (Initials) + اسم المتقدم (قابل للنقر)
        Row(
          children: [
            // ✅ Avatar: GestureDetector يغلف الـ Container
            GestureDetector(
              onTap: widget.onAvatarTap,  // ✅ يستدعي الدالة الممررة من الشاشة الأب
              child: Container(
                width: 44, height: 44,
                decoration: BoxDecoration(
                  color: AppColors.primaryLight,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Center(
                  child: Text(
                    _getInitials(applicantName),  // ✅ يولد الأحرف الأولى
                    style: TextStyle(
                      color: AppColors.primary,
                      fontSize: 16,
                      fontFamily: 'Inter',
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 12),
            
            // ✅ اسم المتقدم
            Expanded(
              child: Text(
                applicantName,
                style: TextStyle(color: c.textPrimary, fontSize: 16, fontFamily: 'Inter', fontWeight: FontWeight.w700),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
            
            // ✅ تاريخ التقديم (ينقل للأسفل ليترك مساحة للاسم)
            Text(_formatDate(app['appliedAt']), style: TextStyle(color: c.textMuted, fontSize: 11, fontFamily: 'Inter')),
          ],
        ),
        const SizedBox(height: 12),
        
        // ✅ صف الحالة + Dropdown (لم يتغير)
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(color: _getStatusColor(_currentStatus).withOpacity(0.1), borderRadius: BorderRadius.circular(100), border: Border.all(color: _getStatusColor(_currentStatus))),
            child: Text(_currentStatus.toUpperCase(), style: TextStyle(color: _getStatusColor(_currentStatus), fontSize: 11, fontFamily: 'Inter', fontWeight: FontWeight.w700)),
          ),
          DropdownButton<String>(
            value: _currentStatus,
            dropdownColor: c.surface,
            underline: const SizedBox(),
            items: ['pending', 'reviewing', 'interview', 'accepted', 'rejected'].map((s) => DropdownMenuItem(value: s, child: Text(s.toUpperCase(), style: TextStyle(fontSize: 11, fontFamily: 'Inter')))).toList(),
            onChanged: (newStatus) async {
              if (newStatus != null && newStatus != _currentStatus) {
                setState(() => _currentStatus = newStatus);
                await widget.onUpdateStatus(newStatus, null);
              }
            },
          ),
        ]),
        const SizedBox(height: 12),
        
        // ✅ الوظيفة المُقدَّم عليها (لم يتغير)
        Row(children: [
          Icon(Icons.work_outline_rounded, size: 14, color: c.textMuted),
          const SizedBox(width: 4),
          Text('${AppLocalizations.of(context).appliedFor}: ${app['offerTitle'] ?? 'Unknown'}', style: TextStyle(color: c.textMuted, fontSize: 12, fontFamily: 'Inter')),
        ]),
      ]),
    );
  }

  String _formatDate(dynamic timestamp) {
    if (timestamp == null) return 'Unknown';
    if (timestamp is Timestamp) {
      final date = timestamp.toDate();
      return '${date.day}/${date.month}/${date.year}';
    }
    return timestamp.toString().substring(0, 10);
  }
}